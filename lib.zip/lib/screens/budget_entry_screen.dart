import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/budget_provider.dart';

class BudgetEntryScreen extends StatefulWidget {
  const BudgetEntryScreen({super.key});

  @override
  State<BudgetEntryScreen> createState() => _BudgetEntryScreenState();
}

class _BudgetEntryScreenState extends State<BudgetEntryScreen> {
  final _formKey = GlobalKey<FormState>();
  final _budgetController = TextEditingController();
  final _daysController = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: const Text('Set Budget')),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(25),
        child: Card(
          child: Padding(
            padding: const EdgeInsets.all(16),
            child: Form(
              key: _formKey,
              child: Column(
                children: [
                  Text(
                    'Masukkan Total Budget dan Total Days',
                    style: GoogleFonts.poppins(
                      fontSize: 16,
                      fontWeight: FontWeight.w500,
                    ),
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _budgetController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Total Budget (Rp)',
                      labelStyle: GoogleFonts.poppins( // Tambahkan gaya font di sini
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: Colors.grey,
                      ),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(9)),
                      prefixIcon: const Icon(Icons.attach_money_outlined),
                    ),
                    validator: (value) => value == null || value.isEmpty ? 'Enter total budget' : null,
                  ),
                  const SizedBox(height: 14),
                  TextFormField(
                    controller: _daysController,
                    keyboardType: TextInputType.number,
                    decoration: InputDecoration(
                      labelText: 'Total Days',
                      labelStyle: GoogleFonts.poppins( // Tambahkan gaya font di sini
                        fontSize: 14,
                        fontWeight: FontWeight.w500,
                        color: Colors.grey,
                      ),
                      border: OutlineInputBorder(borderRadius: BorderRadius.circular(9)),
                      prefixIcon: const Icon(Icons.calendar_today_outlined),
                    ),
                    validator: (value) => value == null || value.isEmpty ? 'Enter total days' : null,
                  ),
                  const SizedBox(height: 14),
                  SizedBox(
                    width: double.infinity,
                    child: ElevatedButton(
                      onPressed: () {
                        if (_formKey.currentState!.validate()) {
                          final budget = double.parse(_budgetController.text);
                          final days = int.parse(_daysController.text);
                          Provider.of<BudgetProvider>(context, listen: false).setBudget(budget, days);
                        }
                      },
                      child: const Text('Save Budget'),
                    ),
                  ),
                ],
              ),
            ),
          ),
        ),
      ),
    );
  }
}
