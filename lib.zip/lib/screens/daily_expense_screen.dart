import 'package:flutter/material.dart';
import 'package:google_fonts/google_fonts.dart';
import 'package:provider/provider.dart';
import '../providers/budget_provider.dart';
import '../widgets/expense_list.dart';
import '../widgets/expense_form.dart';
import 'package:intl/intl.dart';

class DailyExpenseScreen extends StatelessWidget {
  const DailyExpenseScreen({super.key});

  @override
  Widget build(BuildContext context) {
    final provider = Provider.of<BudgetProvider>(context);
    final formatter = NumberFormat.currency(locale: 'id_ID', symbol: 'Rp');

    return Scaffold(
      appBar: AppBar(title: const Text('Pengeluaran Harian')),
      body: Card(
        child: Padding(
          padding: const EdgeInsets.all(16.0),
          child: Column(
            crossAxisAlignment: CrossAxisAlignment.start,
            children: [
              const SizedBox(height: 12),
              Text(
                'Sisa Anggaran : ${formatter.format(provider.budget!.totalBudget - provider.totalSpent)}',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Sisa Hari : ${provider.daysLeft}',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 12),
              Text(
                'Anggaran Harian : ${formatter.format(provider.dailyBudget)}',
                style: GoogleFonts.poppins(
                  fontSize: 16,
                  fontWeight: FontWeight.w500,
                ),
              ),
              const SizedBox(height: 16),
              const ExpenseForm(),
              const SizedBox(height: 16),
              const Expanded(child: ExpenseList()),
            ],
          ),
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () {
          showDialog(
            context: context,
            builder: (context) {
              final controller = TextEditingController();
              return AlertDialog(
                title: Text(
                  'Tambah Anggaran',
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w400,
                  ),
              ),
                content: TextField(
                  style: GoogleFonts.poppins(
                    fontWeight: FontWeight.w300,
                  ),
                  controller: controller,
                  keyboardType: TextInputType.number,
                  decoration: const InputDecoration(hintText: 'Masukkan jumlah'),
                ),
                actions: [
                  TextButton(
                    onPressed: () => Navigator.pop(context),
                    child: Text(
                      'Batal',
                      style: GoogleFonts.poppins(
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ),
                  TextButton(
                    onPressed: () {
                      final amount = int.tryParse(controller.text);
                      if (amount != null && amount > 0) {
                        Provider.of<BudgetProvider>(context, listen: false)
                            .increaseBudget(amount);
                        Navigator.pop(context);
                      }
                    },
                    child: Text(
                      'Tambah',
                      style: GoogleFonts.poppins(
                        fontWeight: FontWeight.w300,
                      ),
                    ),
                  ),
                ],
              );
            },
          );
        },
        child: const Icon(Icons.add),
      ),
    );
  }
}
