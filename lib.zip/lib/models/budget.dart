class Budget {
  final double totalBudget;
  final int totalDays;

  Budget({required this.totalBudget, required this.totalDays});
}